// Interfata pentru decorator

public interface IJoc {
  Fereastra createGame();
}
