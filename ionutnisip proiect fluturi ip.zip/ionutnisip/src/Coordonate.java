public class Coordonate {
	int i;
	int j;

	public Coordonate(int i, int j) {
		this.i = i;
		this.j = j;
	}
}
