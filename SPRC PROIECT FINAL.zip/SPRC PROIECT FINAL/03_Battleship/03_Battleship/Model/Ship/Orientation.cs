﻿
namespace _03_Battleship.Model
{
    using System;


    [Serializable]
    public enum Orientation
    {

        Horizontal,

        Vertical
    }
}