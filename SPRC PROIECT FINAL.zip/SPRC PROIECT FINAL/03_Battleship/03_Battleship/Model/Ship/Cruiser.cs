﻿
namespace _03_Battleship.Model
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;


    [Serializable]
    public class Cruiser : Ship
    {

        public Cruiser()
        {
        }


        public Cruiser(Position position) : base(position)
        {
            this.Length = 3;
        }
    }
}