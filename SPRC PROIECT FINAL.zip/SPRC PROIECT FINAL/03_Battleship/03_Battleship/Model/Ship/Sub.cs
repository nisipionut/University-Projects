﻿
namespace _03_Battleship.Model
{
    using System;


    [Serializable]
    public class Sub : Ship
    {

        public Sub()
        {
        }


        public Sub(Position position) : base(position)
        {
            this.Length = 1;
        }
    }
}