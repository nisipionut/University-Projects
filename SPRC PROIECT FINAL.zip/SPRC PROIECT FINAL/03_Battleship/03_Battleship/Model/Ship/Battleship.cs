﻿
namespace _03_Battleship.Model
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    [Serializable]
    public class Battleship : Ship
    {

        public Battleship()
        {
        }


        public Battleship(Position position) : base(position)
        {
            this.Length = 4;
        }
    }
}