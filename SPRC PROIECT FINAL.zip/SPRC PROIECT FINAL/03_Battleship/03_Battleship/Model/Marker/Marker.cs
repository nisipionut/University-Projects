﻿
namespace _03_Battleship.Model
{
    using System;


    [Serializable]
    public abstract class Marker
    {

        public Marker(Position position)
        {
            this.Position = position ?? throw new ArgumentNullException(nameof(position), "The value must not be null.");
        }


        public Position Position
        {
            get;
            private set;
        }
    }
}