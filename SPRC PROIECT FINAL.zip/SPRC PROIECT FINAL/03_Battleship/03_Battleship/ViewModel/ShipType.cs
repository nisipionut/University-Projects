﻿
namespace _03_Battleship.ViewModel
{

    internal enum ShipType
    {


        Undefined,


        Carrier,

        Battleship,

        Cruiser,


        Destroyer,

        Sub
    }
}
