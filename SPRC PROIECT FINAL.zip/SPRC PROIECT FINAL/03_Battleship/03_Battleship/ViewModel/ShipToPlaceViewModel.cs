﻿
namespace _03_Battleship.ViewModel
{
    using System;
    using Model;
    using MVVMCore;


    internal class ShipToPlaceViewModel : NotifyingViewModel
    {

        private ShipType shipToPlaceType;

        
        private Ship ship;


        private Orientation shipOrientation;

        public ShipType ShipType
        {
            get
            {
                return this.shipToPlaceType;
            }

            set
            {
                this.shipToPlaceType = value;
                this.Notify(nameof(this.ShipText));
            }
        }


        public Ship Ship
        {
            get
            {
                return this.ship;
            }

            set
            {
                this.ship = value;
                this.Notify();
            }
        }

        
        public string ShipText
        {
            get
            {
                switch (this.ShipType)
                {
                    case ShipType.Undefined:
                        return "Nimic selectat";
                    case ShipType.Carrier:
                        return "5 unitati selectate";
                    case ShipType.Battleship:
                        return "4 unitati selectate";
                    case ShipType.Cruiser:
                        return "3 unitati selectate";
                    case ShipType.Destroyer:
                        return "2 unitati selectate";
                    case ShipType.Sub:
                        return "o unitate selectata";
                    default: throw new ArgumentOutOfRangeException(nameof(this.ShipType));
                }
            }
        }

        public Orientation ShipOrientation
        {
            get
            {
                return this.shipOrientation;
            }

            set
            {
                this.shipOrientation = value;
                this.Notify();
            }
        }

        public bool ValidPosition { get; set; }
    }
}
