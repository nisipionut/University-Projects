﻿//-----------------------------------------------------------------------
// <copyright file="SquareState.cs" company="FHWN">
//   FHWN. All rights reserved.
// </copyright>
// <summary>Contains the SquareState enumeration.</summary>
// <author>Thomas Stranz</author>
//-----------------------------------------------------------------------
namespace _03_Battleship.ViewModel
{
    /// <summary>
    /// Represents the SquareState enumeration.
    /// </summary>
    public enum SquareState
    {

        Undamaged,

        Missed,


        Hit,


        Highlighted,

        HightlightedAsWrong
    }
}
