﻿

namespace _03_Battleship.ViewModel
{

    public enum HighlightedState
    {

        NotHighlighted,


        Highlighted,

        HighlightedAsWrong
    }
}
