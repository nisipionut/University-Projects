﻿
namespace _03_Battleship.Command
{
    using Model;
    using MVVMCore;
    using ViewModel.ViewRepresenter;


    internal class RotateShipCommand : BaseCommand
    {
 
        private BattleFieldViewModel battleFieldViewModel;


        public RotateShipCommand(BattleFieldViewModel battleFieldViewModel)
        {
            
        }


        public override void Execute(object parameter)
        {

        }
    }
}
